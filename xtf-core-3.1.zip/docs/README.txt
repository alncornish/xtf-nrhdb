The most recent and definitive version of the XTF documentation is available on
the XTF site at:

    http://xtf.cdlib.org

